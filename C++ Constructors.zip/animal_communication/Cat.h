#include "pch.h"
#include <iostream>

using namespace std;

class Cat
{
public:
	Cat();
	void communicate();
};

