#include "pch.h"
#include <iostream>

using namespace std;

class Dog
{
public:
	Dog();
	void communicate();
};

