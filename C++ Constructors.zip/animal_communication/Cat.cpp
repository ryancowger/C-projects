#include "pch.h"
#include "Cat.h"


Cat::Cat()
{
}

void Cat::communicate()
{
	cout << "meow" << endl;
}



