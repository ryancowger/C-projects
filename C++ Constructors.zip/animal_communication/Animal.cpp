#include "pch.h"
#include <iostream>
#include "Animal.h"

using namespace std;



Animal::Animal()
{
	void communicate(); {
		cout << "speak" << endl; }
}

void Animal::communicate()
{
	cout << "speak" << endl;	
}


