#include "pch.h"
#include <iostream>

using namespace std;

class Animal
{
public:
	Animal();
	void communicate();
	
};

