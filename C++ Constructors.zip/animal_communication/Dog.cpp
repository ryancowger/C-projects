#include "pch.h"
#include "Dog.h"


Dog::Dog()
{
}

void Dog::communicate()
{
	cout << "Woof!" << endl;
}


